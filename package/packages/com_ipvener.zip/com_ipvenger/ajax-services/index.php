<?php
// no direct access
defined('_JEXEC') or die;
?>