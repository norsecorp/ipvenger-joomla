<?php
// no direct access
    defined('_JEXEC') or die;
?>
<div class="banner">
	<div class="banner-links">
		<div id="ipv-settings-url">
<!-- href="<?php 
		//$page = plugin_basename($parent_slug);
		//echo admin_url("admin.php?page=${page}__support" ); 

			?>" -->
			<a href="http://support.ipvenger.com" target="new"
			>Support</a>
		</div>
		<div id="ipv-website-url">
			<a href="http://www.ipvenger.com" target="new">IPVenger Website</a>
		</div>
	</div>
</div>
