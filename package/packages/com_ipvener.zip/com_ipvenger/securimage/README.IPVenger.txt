This is a very stripped down version of securimage captcha, modified for 
use by IPVenger.  The latest complete distribution and documentation are
available from www.phpcaptcha.org.
